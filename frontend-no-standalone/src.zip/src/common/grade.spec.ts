import { Grade } from './grade';

describe('Grade', () => {
  it('should create an instance', () => {
    expect(new Grade()).toBeTruthy();
  });
});
