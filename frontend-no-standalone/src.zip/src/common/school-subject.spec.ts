import { SchoolSubject } from './school-subject';

describe('SchoolSubject', () => {
  it('should create an instance', () => {
    expect(new SchoolSubject()).toBeTruthy();
  });
});
