export class GradeColumn {
    constructor(
        public id: number,
        public title: string,
        public schoolSubject: number
      ) {

      }
}
