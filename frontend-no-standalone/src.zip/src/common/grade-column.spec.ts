import { GradeColumn } from './grade-column';

describe('GradeColumn', () => {
  it('should create an instance', () => {
    expect(new GradeColumn()).toBeTruthy();
  });
});
